package tester;

//
import static utils.HibernateUtils.*;

import org.hibernate.SessionFactory;

import dao.CustomerDaoImpl;

public class ListAllCustomers {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf()) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			new CustomerDaoImpl().listCustomers().forEach(System.out::println);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
