package dao;

import pojos.Customer;
import org.hibernate.*;
import static utils.HibernateUtils.*;

import java.util.List;

public class CustomerDaoImpl implements CustomerDao {

	@Override
	public String registerCustomer(Customer c) {
		Integer id = null;
		// get session from SF
		Session hs = getSf().openSession(); // L1 cache is auto created
		// tx
		Transaction tx = hs.beginTransaction();
		try {
			id = (Integer) hs.save(c);// i/p transient POJO ref --> PERSISTENT
			tx.commit(); // insert query is fired
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		} finally {
			if (hs != null)
				hs.close();// ret db cn to pool , destroys L1 cache , closes HS
		}
		return "Customer reged successfully with ID " + id;
	}

	@Override
	public Customer fetchCustomerDetails(int id) {
		Customer c=null;
		// hs
		Session hs=getSf().openSession();
		//tx
		Transaction tx=hs.beginTransaction();
		try {
			c=hs.get(Customer.class, id);
			tx.commit();
		}catch (Exception e) {
			if(tx != null)
				tx.rollback();
			throw e;
		} finally {
			if(hs != null)
				hs.close();
		}
		return c;
	}

	@Override
	public List<Customer> listCustomers() {
		List<Customer> l1=null;
		String jpql="select c from Customer c";
		Session hs=getSf().openSession();
		//tx
		Transaction tx=hs.beginTransaction();
		try {
			l1=hs.createQuery(jpql, Customer.class).getResultList();//rets a list of PERSISTENT pojos.
			tx.commit();
		}catch (Exception e) {
			if(tx != null)
				tx.rollback();
			throw e;
		} finally {
			if(hs != null)
				hs.close();
		}
		return l1;
	}
	

}



