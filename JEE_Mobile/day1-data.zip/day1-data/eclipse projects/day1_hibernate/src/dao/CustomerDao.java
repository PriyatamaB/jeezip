package dao;

import java.util.List;

import pojos.Customer;

public interface CustomerDao {
	String registerCustomer(Customer c);
	Customer fetchCustomerDetails(int id);
	List<Customer> listCustomers();

}
