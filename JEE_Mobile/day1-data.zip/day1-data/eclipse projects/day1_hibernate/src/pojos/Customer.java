package pojos;

import java.util.Date;
//package for all JPA annotations
import javax.persistence.*;

@Entity //mandatory --class level
@Table(name="sunbeam_new_custs")
public class Customer {
	private Integer custId;
	private String name,email,password;
	private double regAmount;
	private Date regDate;
	private CustomerType custType;
	private byte[] photo;
	//def constr MANDATORY
	public Customer() {
		System.out.println("in constr of "+getClass().getName());
	}
	public Customer(String name, String email, String password, double regAmount, Date regDate, CustomerType custType) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.regAmount = regAmount;
		this.regDate = regDate;
		this.custType = custType;
	}
	//ALL getters n setters
	@Id // assigned type of generator --supplied by user
	@GeneratedValue(strategy=GenerationType.IDENTITY) //auto inc --for MySQL
	//for oracle --- AUTO/SEQUENCE
	@Column(name="cust_id")
	public Integer getCustId() {
		return custId;
	}
	public void setCustId(Integer custId) {
		this.custId = custId;
	}
	@Column(length=20)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(length=20,unique=true)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(length=20)
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Column(name="reg_amt")
	public double getRegAmount() {
		return regAmount;
	}
	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}
	@Column(name="reg_date")
	@Temporal(TemporalType.DATE) //date type of column
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	@Enumerated(EnumType.STRING)
	@Column(name="cust_type")
	public CustomerType getCustType() {
		return custType;
	}
	public void setCustType(CustomerType custType) {
		this.custType = custType;
	}
	@Lob
	public byte[] getPhoto() {
		return photo;
	}
	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", regAmount=" + regAmount + ", regDate=" + regDate + ", custType=" + custType + "]";
	}
	
	
	
	

}
