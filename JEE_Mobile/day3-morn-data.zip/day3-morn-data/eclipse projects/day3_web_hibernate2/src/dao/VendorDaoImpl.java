package dao;

import java.util.List;

import org.hibernate.*;

import static utils.HibernateUtils.*;
import pojos.Vendor;

public class VendorDaoImpl implements VendorDao {

	@Override
	public List<Vendor> listVendors() {
		List<Vendor> list=null;
		String jpql="select new Vendor(id,name,email,city,phoneNo) from Vendor v";
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		try {
			list=hs.createQuery(jpql, Vendor.class).getResultList();
			tx.commit();
		} catch (HibernateException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return list;
	}

}
