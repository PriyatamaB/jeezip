package dao;

import java.util.List;

import pojos.Vendor;

public interface VendorDao {
	List<Vendor> listVendors();

}
