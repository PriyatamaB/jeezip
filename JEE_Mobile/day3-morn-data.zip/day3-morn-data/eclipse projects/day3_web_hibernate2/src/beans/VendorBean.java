package beans;

import java.util.List;

import dao.VendorDaoImpl;
import pojos.Vendor;

public class VendorBean {
	private VendorDaoImpl dao;
	public VendorBean() {
		dao=new VendorDaoImpl();
	}
	//B.L method to fetch all vendor details
	public List<Vendor> listVendors()
	{
		System.out.println("in jb : list vendors");
		return dao.listVendors();
	}

}
