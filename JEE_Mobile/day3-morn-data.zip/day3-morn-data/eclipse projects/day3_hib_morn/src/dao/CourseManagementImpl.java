package dao;
import org.hibernate.*;
import static utils.HibernateUtils.*;
import pojos.*;

public class CourseManagementImpl implements CourseManagementDao {

	@Override
	public String launchCourseWithStudents(Course c) {
		String mesg="Course launching failed....";
		//hs
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		try {
			hs.save(c);
			tx.commit();
			mesg="Course launched successfully...";
		}catch (HibernateException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		
		return mesg;
	}

	@Override
	public String registerStudentToCourse(int courseId, Student s) {
		String mesg="Student admission failed....";
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		try {
			//get course
			Course c=hs.get(Course.class, courseId);
			if(c != null)
			{
				//valid course : c --- persistent
				c.addStudent(s);
				mesg="Student admitted with success";
			}
			tx.commit();
			
			
		}catch (HibernateException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public Course getCourseDetails(String name1) {
		Course c=null;
		String jpql="select c from Course c where c.name = :nm";
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		try {
			c=hs.createQuery(jpql, Course.class).
					setParameter("nm",name1).getSingleResult();
			//valid course id : c--- persistent
			tx.commit();
			
		}catch (HibernateException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return c;//c--- detached
	}

	@Override
	public Course getCourseDetailsWithStudents(String name1) {
		Course c=null;
	//	String jpql="select c from Course c where c.name = :nm";
		String jpql="select c from Course c join fetch c.students where c.name = :nm";
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		try {
			c=hs.createQuery(jpql, Course.class).
					setParameter("nm",name1).getSingleResult();
			//valid course id : c--- persistent
			//access student details  --via size of the collection
		//	System.out.println(c.getStudents().size());
			tx.commit();
			
		}catch (HibernateException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return c;//c--- detached
	
	}
	
	
	

}
