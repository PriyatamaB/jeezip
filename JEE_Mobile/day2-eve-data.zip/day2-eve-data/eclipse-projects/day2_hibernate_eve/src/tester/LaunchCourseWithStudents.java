package tester;

//
import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CourseManagementImpl;
import pojos.Course;
import pojos.Student;

public class LaunchCourseWithStudents {

	public static void main(String[] args) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			System.out.println("Enter course details nm begin end fees");
			Course c1 = new Course(sc.next(), sdf.parse(sc.next()), sdf.parse(sc.next()), sc.nextDouble());
			System.out.println("Enter 1st student dtls");
			Student s1 = new Student(sc.next());
			c1.addStudent(s1);
			System.out.println("Enter 2nd student dtls");
			Student s2 = new Student(sc.next());
			c1.addStudent(s2);
			System.out.println(new CourseManagementImpl().launchCourseWithStudents(c1));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
