package pojos;
import javax.persistence.*;

@Entity
@Table(name="cdac_students")
public class Student {
	private Integer studentId;
	private String email;
	private Course myCourse;
	public Student() {
		System.out.println("in stud constr");
	}
	public Student(String email) {
		super();
		this.email = email;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="stud_id")
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	@Column(length=20,unique=true)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@ManyToOne //mandatory o.w MappingExc
	@JoinColumn(name="c_id") //FK col. details optional BUT reco
	public Course getMyCourse() {
		return myCourse;
	}
	public void setMyCourse(Course myCourse) {
		this.myCourse = myCourse;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", email=" + email + "]";
	}
	

}
