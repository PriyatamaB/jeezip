package pojos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name="cdac_courses")
public class Course {
	private Integer courseId;
	private String name;
	private Date beginDate,endDate;
	private double fees;
	private List<Student> students=new ArrayList<>();
	public Course() {
		System.out.println("in course constr");
	}
	public Course(String name, Date beginDate, Date endDate, double fees) {
		super();
		this.name = name;
		this.beginDate = beginDate;
		this.endDate = endDate;
		this.fees = fees;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="course_id")
	public Integer getCourseId() {
		return courseId;
	}
	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}
	@Column(length=20,unique=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="begin_dt")
	@Temporal(TemporalType.DATE)
	public Date getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}
	@Column(name="end_dt")
	@Temporal(TemporalType.DATE)
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	@Column(columnDefinition="double(8,1)")
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	@OneToMany(mappedBy="myCourse",cascade=CascadeType.ALL)
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	//convenience methods --- bi dir association --optional BUT reco
	public void addStudent(Student s)
	{
		students.add(s);
		s.setMyCourse(this);
	}
	public void removeStudent(Student s)
	{
		students.remove(s);
		s.setMyCourse(null);
	}
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", name=" + name + ", beginDate=" + beginDate + ", endDate=" + endDate
				+ ", fees=" + fees + "]";
	}
	
	

}
