package dao;
import org.hibernate.*;
import static utils.HibernateUtils.*;
import pojos.*;

import pojos.Course;

public class CourseManagementImpl implements CourseManagementDao {

	@Override
	public String launchCourseWithStudents(Course c) {
		String mesg="Course launching failed....";
		//hs
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		try {
			hs.save(c);
			tx.commit();
			mesg="Course launched successfully...";
		}catch (HibernateException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		
		return mesg;
	}

}
