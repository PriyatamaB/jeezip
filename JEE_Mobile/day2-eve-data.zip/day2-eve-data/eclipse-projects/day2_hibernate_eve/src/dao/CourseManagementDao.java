package dao;

import pojos.Course;

public interface CourseManagementDao {
	String launchCourseWithStudents(Course c);

}
