package com.app.service;

import pojos.User;

public interface UserServiceIntf {
	User validateUser(String em,String pass);
}
