package dto;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class StudentDTO {
	private Integer studentId;
	private String email;
	private String name;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dob;

	public StudentDTO() {
		System.out.println("in constr" + getClass().getName());
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "StudentDTO [studentId=" + studentId + ", email=" + email + ", name=" + name + ", dob=" + dob + "]";
	}
	

}
