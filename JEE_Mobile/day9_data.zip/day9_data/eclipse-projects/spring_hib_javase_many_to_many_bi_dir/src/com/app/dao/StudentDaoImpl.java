package com.app.dao;



import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Course;
import com.app.pojos.Student;

@Repository
@Transactional
public class StudentDaoImpl implements StudentDao {
	@Autowired
	private SessionFactory sf;

	@Override
	public String addStudentToCourse(int courseId, int studentId) {
		String mesg="Student admitted to course";
		//get course details
		Course c=sf.getCurrentSession().get(Course.class, courseId);
		//get student dtls
		Student s=sf.getCurrentSession().get(Student.class, studentId);
		c.addStudent(s);
		return mesg;
	}

	@Override
	public String cancelAdmissionFromCourse(int courseId, int studentId) {
		String mesg="Student admission to a course cancelled";
		//get course details
		Course c=sf.getCurrentSession().get(Course.class, courseId);
		//get student dtls
		Student s=sf.getCurrentSession().get(Student.class, studentId);
		c.removeStudent(s);
		return mesg;
	}

	

}
