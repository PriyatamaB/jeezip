package com.app.dao;

import com.app.pojos.Student;

public interface StudentDao {
	String addStudentToCourse(int courseId, int studentId);

	String cancelAdmissionFromCourse(int courseId, int studentId);
}
