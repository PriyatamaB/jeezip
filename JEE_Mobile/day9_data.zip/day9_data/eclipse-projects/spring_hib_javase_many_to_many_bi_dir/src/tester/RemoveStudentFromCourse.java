package tester;

import java.util.Date;
import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.app.dao.StudentDao;
import com.app.pojos.Student;

public class RemoveStudentFromCourse {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in);
				ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("main-config.xml")) {
			System.out.println("sc strted");
			// get bean from SC
			StudentDao dao = ctx.getBean("studentDaoImpl", StudentDao.class);
			System.out.println("course id n student id");
			System.out.println(dao.cancelAdmissionFromCourse(sc.nextInt(), sc.nextInt()));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
