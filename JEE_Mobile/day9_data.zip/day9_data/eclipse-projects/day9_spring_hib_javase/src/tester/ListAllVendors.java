package tester;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.app.service.VendorManagementService;

public class ListAllVendors {

	public static void main(String[] args) {
		try(ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("spring-servlet.xml"))
		{
			System.out.println("SC Started");
			//invoke service layer method
			VendorManagementService service=ctx.getBean(VendorManagementService.class);
			service.listVendors().forEach(System.out::println);
			
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
