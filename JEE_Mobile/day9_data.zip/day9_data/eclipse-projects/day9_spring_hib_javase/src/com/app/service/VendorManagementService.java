package com.app.service;

import java.util.List;

import com.app.pojos.Vendor;

public interface VendorManagementService {
	List<Vendor> listVendors();
	Vendor authenticateUser(String email,String password);
	String registerVendor(Vendor transientVendor);
}
