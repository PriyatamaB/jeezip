package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.VendorManagementDao;
import com.app.pojos.Vendor;
@Service
@Transactional
public class VendorManagementServiceImpl implements VendorManagementService {
	//dependency
	@Autowired
	private VendorManagementDao dao;
	@Override
	public List<Vendor> listVendors() {
		// TODO Auto-generated method stub
		return dao.listVendors();
	}
	@Override
	public Vendor authenticateUser(String email, String password) {
		return dao.authenticateUser(email, password);
	}
	@Override
	public String registerVendor(Vendor transientVendor) {
		// TODO Auto-generated method stub
		return dao.registerVendor(transientVendor);
	}
	
	

}
