package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Vendor;

@Repository
public class VendorManagementDaoImpl implements VendorManagementDao {
	// dependency
	@Autowired
	private SessionFactory sf;

	@Override
	public List<Vendor> listVendors() {
		System.out.println("in dao : list vendors");
		String jpql = "select v from Vendor v";
		return sf.getCurrentSession().createQuery(jpql, Vendor.class).getResultList();
	}

	@Override
	public Vendor authenticateUser(String email1, String password1) {
		String jpql = "select v from Vendor v where v.email = :em and v.password=:pa";
		return sf.getCurrentSession().createQuery(jpql, Vendor.class).setParameter("em", email1)
				.setParameter("pa", password1).getSingleResult();
	}

	@Override
	public String registerVendor(Vendor transientVendor) {
		sf.getCurrentSession().save(transientVendor);
		return "Vendor reged successfully..."+transientVendor.getId();
	}
	

}
