package dto;

import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;



public class StudentDTO {
	private Integer studentId;
	@NotEmpty(message="Email required")
	@Email(message="Invalid Email format")
	private String email;
	@Pattern(regexp="((?=.*\\d)(?=.*[a-z])(?=.*[#@$*]).{4,10})",message="invalid passord")
	private String password;
	@NotNull(message="fees must be supplied")
	@Range(min=500,max=5000,message="Invalid range...")
	private double regFees;
	@NotEmpty(message="Name required")
	private String name;
	@NotNull
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dob;

	public StudentDTO() {
		System.out.println("in constr" + getClass().getName());
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}
	

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public double getRegFees() {
		return regFees;
	}

	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}

	@Override
	public String toString() {
		return "StudentDTO [studentId=" + studentId + ", email=" + email + ", name=" + name + ", dob=" + dob + "]";
	}
	

}
