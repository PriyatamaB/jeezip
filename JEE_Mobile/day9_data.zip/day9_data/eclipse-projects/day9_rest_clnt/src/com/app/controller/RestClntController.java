package com.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import dto.StudentDTO;

@Controller
@RequestMapping("/student")
public class RestClntController {
	// SpEl spring Expression language
	@Value("#{props.GET_STUDTENT_URL}")
	private String url1;

	@Value("#{props.GET_ALL_STUDENTS_URL}")
	private String url2;

	@Value("#{props.CREATE_STUDENT_URL}")
	private String url3;

	public RestClntController() {
		System.out.println("in constr " + getClass().getName());
	}

	@GetMapping("/fetch_dtls/{stud_id}")
	public String fetchStudentDetails(@PathVariable int stud_id, RestTemplate template, Model map) {
		System.out.println("in rest clnt : fetch " + stud_id);
		try {
			// invoke REST API
			StudentDTO s = template.getForObject(url1, StudentDTO.class, stud_id);
			map.addAttribute("mesg", "Student details " + s);
		} catch (HttpClientErrorException e) {
			map.addAttribute("mesg", e.getStatusCode() + " " + e.getResponseBodyAsString());
		}

		return "/student/details";

	}

	@GetMapping("/fetch_all_dtls")
	public String fetchAllStudentDetails(RestTemplate template, Model map) {
		System.out.println("in rest clnt : fetch all");

		// invoke REST API
		map.addAttribute("student_list", template.getForObject(url2, List.class));

		return "/student/details2";

	}

	// show reg form
	@GetMapping("/register")
	public String showRegForm(StudentDTO s) {
		System.out.println("in rest clnt : show reg form " + s);
		return "/student/register";

	}

	// process reg form (with P.L validations)
	@PostMapping("/register")
	public String processRegForm(@Valid StudentDTO s,BindingResult result, RestTemplate template, RedirectAttributes flashMap) {
		System.out.println("in rest clnt : process reg form " + s);
		if(result.hasErrors())
		{
			System.out.println("P.L errs");
			return "/student/register";
		}
		System.out.println("no p.l errs");
		flashMap.addFlashAttribute("resp", template.postForObject(url3, s, String.class));
		return "redirect:/student/details3";

	}

	// forward user to view layer --global method
	@GetMapping("/{url123}")
	public String forwardToView(@PathVariable String url123) {
		System.out.println("in forward to view " + url123);
		return "/student/" + url123;
	}

}
