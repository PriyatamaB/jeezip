package pojos;

public enum CustomerType {
	SILVER,GOLD,PLATINUM
}
