package tester;

import java.util.Date;
import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.app.pojos.Location;
import com.app.pojos.Student;
import com.app.pojos.StudentDetails;
import com.app.service.StudentService;

public class TestSpringHibernate {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in);
				ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("main-config.xml")) {
			System.out.println("sc strted");
		}

	}

}
