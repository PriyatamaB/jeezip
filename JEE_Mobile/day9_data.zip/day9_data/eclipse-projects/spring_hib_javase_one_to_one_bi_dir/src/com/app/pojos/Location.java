package com.app.pojos;

public enum Location {
	ACTS,SUNBEAM,IACSD,INFOWAY,KNOWIT;
}
