package com.app.dao;

public interface AccountDao {
	String updateBalance(String email, double amt);
}
