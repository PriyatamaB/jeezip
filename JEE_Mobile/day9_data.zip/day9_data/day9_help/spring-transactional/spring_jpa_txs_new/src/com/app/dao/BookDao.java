package com.app.dao;

public interface BookDao {
	double getPrice(String isbn);
}
