package com.app.dao;

public interface BookStoreDao {
	String purchaseBooks(String email,String isbn,int qty);

}
