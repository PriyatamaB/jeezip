package com.app.service;

public interface UserService {
	boolean userExists(String name);
}
