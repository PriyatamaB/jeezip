package com.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.MovieDao;
import com.app.pojos.Movie;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/movies")
public class MovieController {
	@Autowired
	private MovieDao dao;

	@GetMapping
	public List<Movie> testMe() {
		ArrayList<Movie> l1 = new ArrayList<>();
		dao.findAll().forEach(l1::add);
		System.out.println("in rest server : list"+l1);
		return l1;
	}
	@PostMapping
	public String addMovie(@RequestBody Movie m)
	{
		System.out.println("rest server : add movie "+m);
		dao.save(m);
		return "Movie added";
	}
}
