package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Student;

@Repository
@Transactional
public class StudentDaoImpl implements StudentDao {
	@PersistenceContext //L1 cache --env where all managed pojos
	//are stroed --PERSISTENT entities
	private EntityManager mgr; //equivalent Session i/f

	@Override
	public Student getStudentDetails(int id) {
		// TODO Auto-generated method stub
		return mgr.find(Student.class, id);
	}

	@Override
	public List<Student> getAllStudentDetails() {
		String jpql = "select s from Student s";
		return mgr.createQuery(jpql, Student.class).getResultList();
	}

	@Override
	public String registerStudent(Student s) {
		System.out.println("in dao --reg stud "+s);
		mgr.persist(s);
		return "Student reged successfully with id "+s.getStudentId();
				
	}

	@Override
	public String deleteStudent(Student s) {
		mgr.remove(s);
		return "Student details deleted successfully with id "+s.getStudentId();
	}

	@Override
	public String updateStudent(Student s) {
		mgr.merge(s);
		return "Student details updated successfully with id "+s.getStudentId();
	}
	
	
	
	

}
