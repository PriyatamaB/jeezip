package dto;

import java.util.Date;

public class UserDTO {
	private String email,password,prefs;
	private Date regDate;
	private double regAmount;
	public UserDTO() {
		System.out.println("in user dto constr");
	}
	public UserDTO(String email, String password, String prefs, Date regDate,
			double regAmount) {
		super();
		this.email = email;
		this.password = password;
		this.prefs = prefs;
		this.regDate = regDate;
		this.regAmount = regAmount;
	}




	public String getEmail() {
		
		return email;
	}



	public void setEmail(String email) {
		System.out.println("in set email");
		this.email = email;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getPrefs() {
		return prefs;
	}



	public void setPrefs(String prefs) {
		this.prefs = prefs;
	}



	public Date getRegDate() {
		return regDate;
	}



	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}



	public double getRegAmount() {
		return regAmount;
	}



	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}



	@Override
	public String toString() {
		return "UserDTO [email=" + email + ", password=" + password
				+ ", prefs=" + prefs + ", regDate=" + regDate + ", regAmount="
				+ regAmount + "]";
	}
	

}
