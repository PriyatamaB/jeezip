package actions;

import java.util.Date;
import java.util.HashMap;

import com.opensymphony.xwork2.ActionSupport;

import dto.UserDTO;

public class LoginAction extends ActionSupport {
	// props ---clnt's conversational state -- req param names
	private String email, pass;
	private HashMap<String, UserDTO> users;
	private UserDTO userDetails;// to store validated user details

	// def constr
	public LoginAction() {
		System.out.println("in cnstr of L.A.");
		users = new HashMap<>();
		users.put("a@gmail", new UserDTO("a@gmail", "1234", "prefs1",
				new Date(), 500));
		users.put("b@gmail", new UserDTO("b@gmail", "134", "prefs2", new Date(),
				1500));
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		System.out.println("in set email");
		this.email = email;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public HashMap<String, UserDTO> getUsers() {
		return users;
	}

	public void setUsers(HashMap<String, UserDTO> users) {
		this.users = users;
	}

	public UserDTO getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDTO userDetails) {
		this.userDetails = userDetails;
	}
	//B.L 
	@Override
	public String execute() throws Exception
	{
		System.out.println("in exec of LA");
		if(users.containsKey(email))
		{
			UserDTO u=users.get(email);
			if(u.getPassword().equals(pass))
			{
				userDetails=u;
				return "valid";
			}
		}
		return "invalid";
	}

}
