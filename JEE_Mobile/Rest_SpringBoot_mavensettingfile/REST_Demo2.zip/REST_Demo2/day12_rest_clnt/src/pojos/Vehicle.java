package pojos;
import javax.persistence.*;

import org.hibernate.validator.constraints.NotEmpty;

@Embeddable
public class Vehicle {
	
	@NotEmpty(message="Vehicle reg no can't be blank")
	private String regNo;
	@NotEmpty(message="Vehicle model can't be blank")
	private String model;
	
	public Vehicle() {
		System.out.println("in vehicle constr");
	}
	
	

	public Vehicle(String regNo, String model) {
		super();
		this.regNo = regNo;
		this.model = model;
	}

	@Column(name="reg_no",unique=true,length=20)
	public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}
	@Column(length=20)
	public String getModel() {
		return model;
	}



	public void setModel(String model) {
		this.model = model;
	}



	@Override
	public String toString() {
		return "Vehicle [regNo=" + regNo + ", model=" + model + "]";
	}
	
	
	

}
