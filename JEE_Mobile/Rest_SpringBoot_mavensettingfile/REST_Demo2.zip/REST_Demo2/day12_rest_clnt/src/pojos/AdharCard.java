package pojos;
import java.util.Date;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;


@Embeddable
public class AdharCard {
	
	@NotEmpty(message="Adhar Number is required")
	private String adharNumber;
	@NotNull
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date createdOn;
	
	public AdharCard() {
		System.out.println("in adhar card constr");
	}
	public AdharCard(String adharNumber) {
		super();
		this.adharNumber = adharNumber;
	}
	
	@Column(name="card_num",unique=true,length=20)
	public String getAdharNumber() {
		return adharNumber;
	}
	public void setAdharNumber(String adharNumber) {
		this.adharNumber = adharNumber;
	}
	@Temporal(TemporalType.DATE)
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	@Override
	public String toString() {
		return "AdharCard [adharNumber=" + adharNumber + ", createdOn=" + createdOn + "]";
	}
	
	
	

}
