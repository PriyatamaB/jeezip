package com.app.service;

import java.util.List;

public interface DataService {
	List<String> getCities();
	List<Double> getAmounts();
	
}
