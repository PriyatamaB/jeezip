package com.app.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pojos.BankAccount;

@Controller
@RequestMapping("/bank")
public class BankAccountController {
	@Value("#{abc.REST_GET_URL}")
	private String getURL;
	@Value("#{abc.REST_POST_URL}")
	private String postURL;
	@Value("#{abc.REST_PUT_URL}")
	private String putURL;
	@Value("#{abc.REST_POST_URL}")
	private String deleteURL;

	@GetMapping("/summary")
	public String showSummaryForm() {
		System.out.println("show summary form");
		return "/bank/summary";
	}

	@PostMapping("/summary")
	public String processSummaryForm(@RequestParam int id, @RequestParam int pin, RestTemplate template,
			RedirectAttributes flashMap) {
		System.out.println("in process summary form " + getURL);
		try {
			// Invoke REST API to fetch a/c summary from Net Banking server.
			BankAccount a = template.getForObject(getURL, BankAccount.class, id, pin);
			System.out.println("a="+a);
			flashMap.addFlashAttribute("status", "A/C Summary " + a);
		} catch (HttpClientErrorException e) {
			flashMap.addFlashAttribute("status",e.getResponseBodyAsString());
		}
		return "redirect:/vendor/list";
	}

	@GetMapping("/create")
	public String showCreateAcForm(BankAccount a) {
		System.out.println("show create ac form " + a);
		return "/bank/create";
	}

	@PostMapping("/create")
	public String processCreateForm(BankAccount a, RestTemplate template, RedirectAttributes flashMap) {
		System.out.println("in process create a/c  form " + postURL + " " + a);
		try {
			// Invoke REST API to create new a/c1
			String sts = template.postForObject(postURL, a, String.class);
			flashMap.addFlashAttribute("status", sts);
		} catch (RestClientException e) {
			flashMap.addFlashAttribute("status", e.getMessage());
		}
		return "redirect:/vendor/list";
	}

	@GetMapping("/update")
	public String showAcUpdateForm(BankAccount a) {
		System.out.println("in show a/c update form ");
		return "/bank/update";
	}

	@PostMapping("/update")
	public String processAcUpdateForm(BankAccount a, @RequestParam double amount, RestTemplate template,
			RedirectAttributes attr, Model map) {
		System.out.println("in process a/c update form " + a + " " + amount);
		System.out.println("url " + putURL);
		try {
			template.put(putURL, a, amount);
			attr.addFlashAttribute("status", "A/C Updated successfully!!! ");
			return "redirect:/vendor/list";
		} catch (HttpClientErrorException e) {
			map.addAttribute("status", "Resp Body " + e.getResponseBodyAsString() + " " + e.getStatusText());
			return "/bank/update";
		}
	}

	// global mapping method for showing the form
	// with BankAccount added in the model map
	@GetMapping("/{path}")
	public String showForm(BankAccount a, @PathVariable String path) {
		System.out.println("in show  a/c form " + path);
		return "/bank/" + path;
	}

	@PostMapping("/close")
	public String processAcCloseForm(BankAccount a, RestTemplate template, Model map, RedirectAttributes attr) {
		System.out.println("in process a/c close form " + a.getAcctId() + " " + a.getPin());
		System.out.println("url " + deleteURL);
		try {
			template.delete(deleteURL, a.getAcctId(), a.getPin());
			attr.addFlashAttribute("status", "A/C Closed ");
			return "redirect:/vendor/list";
		} catch (RestClientException e) {
			map.addAttribute("status", e.getMessage());
			return "/bank/close";
		}

	}

}
