package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.VendorDao;

import pojos.Part;
import pojos.Vendor;

@Service
@Transactional
public class VendorServiceImpl implements VendorService {
	@Autowired
	private VendorDao dao;

	@Override
	public List<Vendor> listVendors() {

		return dao.listVendors();
	}

	@Override
	public String registerVendor(Vendor v) {
		// TODO Auto-generated method stub
		return dao.registerVendor(v);
	}

	@Override
	public String updateVendor(Vendor v) {
		// TODO Auto-generated method stub
		return dao.updateVendor(v);
	}

	@Override
	public Vendor getVendorDetails(int id) {
		Vendor v = dao.getVendorDetails(id);
		// for showing Vendor & its vehicle details (one --many )
		// w/o Lazy Init exc
		v.getVehicles().size();
		return v;
	}

	@Override
	public String addPart(int vid, Part p) {
		System.out.println("vendor service " + vid + "\n" + p);
		Vendor v = dao.getVendorDetails(vid);// rets PERSISTENT Vendor POJO
		v.addPart(p);
		return dao.addPart(v);
	}

	@Override
	public String deleteVendor(int id) {
		// get vendor details by id
		Vendor v = dao.getVendorDetails(id);
		return dao.deleteVendor(v);
	}

}
