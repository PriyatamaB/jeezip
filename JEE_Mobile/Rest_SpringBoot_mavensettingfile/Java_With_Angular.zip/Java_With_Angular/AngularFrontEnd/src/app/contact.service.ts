import { Injectable } from '@angular/core';
import {Http,Headers,RequestOptions} from '@angular/http';
@Injectable()
export class ContactService {
  url:string="http://localhost:8080/SpringBackEnd/contact";
  
  http:Http

  constructor( http:Http) {
    this.http = http;
   }

   getAllContact()
   {
     return this.http.get(this.url);
   }

   saveContact(contact)
   {
     let contactStr = JSON.stringify(contact); 
     let headers = new Headers({'content-type':'application/json'});
     let option = new RequestOptions({headers:headers});
     return this.http.post(this.url,contactStr,option);
   }

   deleteContact(id)
   {
     return this.http.delete(this.url+"/"+id);
   }

   getContactById(id)
   {
    return this.http.get(this.url+"/"+id);
   }

   updateContact(id,contact)
   {
     let contactStr=JSON.stringify(contact);
     let headers = new Headers({'content-type':'application/json'});
     let option = new RequestOptions({headers:headers});
     return this.http.put(this.url+"/"+id,contactStr,option);
   }
}
