import { Component, OnInit,TemplateRef } from '@angular/core';
import {Router} from '@angular/router'
import {ContactService} from './../contact.service'
import {BsModalRef,BsModalService} from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})

export class ContactComponent implements OnInit {
  service:ContactService;
  router:Router
  selectedContact=undefined;
  contacts=[];
  public modalRef:BsModalRef;
  
  constructor(service:ContactService,router:Router,private modalServise:BsModalService)
  {
    this.service = service;
    this.router = router;
    this.loadContact();
   }

   selectContact(contact)
   {
     this.selectedContact = contact;
   }

   loadContact()
   {
     this.service.getAllContact().subscribe(response=>{
      this.contacts = response.json();
     });
     console.log(this.contacts);
   }

   saveContact(form){
    let contact = form.value;
    console.log(contact);
    return this.service.saveContact(contact).subscribe(response=>{
      this.loadContact();
    });
   }

   deleteContact()
   {
     this.service.deleteContact(this.selectedContact.id).subscribe(response=>{
      console.log(response);
      this.loadContact();
     });
   }

  

  openSaveContactModal(saveTemplate:TemplateRef<any>)
  {
    this.modalRef = this.modalServise.show(saveTemplate);
  }

  openDeleteContactDialog(deleteTemplate)
  {
    this.modalRef = this.modalServise.show(deleteTemplate);
  }

  openUpdateContactDialog(updateTemplate)
  {
    this.modalRef = this.modalServise.show(updateTemplate);
  }

  ngOnInit() {
  }
  
  updateContact(id,form)
  {
    let contact = form.value;
    this.service.updateContact(this.selectedContact.id,contact).subscribe(response=>{
      this.loadContact();
     });
  }
}
