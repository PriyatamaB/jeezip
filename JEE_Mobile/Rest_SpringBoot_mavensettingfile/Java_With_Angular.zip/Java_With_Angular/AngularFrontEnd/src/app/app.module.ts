import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {HttpModule} from '@angular/http';
import {FormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router'
import {BrowserAnimationsModule} from '@angular/platform-browser/animations'

import {ModalModule} from 'ngx-bootstrap/modal';

import {AppComponent} from './app.component';
import {ContactComponent} from './contact/contact.component';
import {ContactService} from './contact.service';


@NgModule({
  declarations: [
    AppComponent,
    ContactComponent,
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    BrowserAnimationsModule,
    ModalModule.forRoot(),
    RouterModule.forRoot([
      {path:"list",component:ContactComponent}
    ])
  ],
  entryComponents:[],    
  providers: [
    ContactService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
