package com.backend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.backend.dao.ContactDao;
import com.backend.pojo.Contact;

@Service
@Transactional
public class ContactServiceImpl implements ContactService 
{

	@Autowired
	private ContactDao dao;
	@Override
	public List<Contact> getAllContact() {
		return dao.getAllContact();
	}

	@Override
	public void addContact(Contact contact) {
		dao.addContact(contact);
		
	}

	@Override
	public void deleteContact(int id) {
		dao.deleteContact(id);
	}

	@Override
	public void updateContact(Contact contact) {
		dao.updateContact(contact);
	}


	@Override
	public Contact getContactById(int id) {
		return dao.getContactById(id);
	}

}
