package com.backend.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.util.UriComponentsBuilder;
import com.backend.pojo.Contact;
import com.backend.service.ContactService;

@RestController
@EnableWebMvc
@CrossOrigin
public class ContactController 
{
	@Autowired
	private ContactService service;
	

	@CrossOrigin
	@RequestMapping(value="/contact",method=RequestMethod.GET,headers="Accept=application/json")
	public List<Contact> getAllContact()
	{
		List<Contact> contacts = service.getAllContact();
		return contacts;
	}
	
	
	@RequestMapping(value="/contact",method=RequestMethod.POST)
	public ResponseEntity<Void> addContact(@RequestBody Contact contact)
	{
		service.addContact(contact);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
		
	@RequestMapping(value="/contact/{id}",method=RequestMethod.DELETE)
	public ResponseEntity<Void> deleteContact(@PathVariable("id") int id)
	{
		service.deleteContact(id);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}	
	
	@RequestMapping(value="/contact/{id}",method=RequestMethod.PUT)
	public ResponseEntity<Void> updateContact(@PathVariable("id") int id,@RequestBody Contact contact)
	{
		Contact newContact = service.getContactById(id);
		System.out.println("Inside Update");
		
		newContact.setName(contact.getName());
		newContact.setEmail(contact.getEmail());
		newContact.setAddress(contact.getAddress());
		newContact.setPhone(contact.getPhone());
		service.updateContact(newContact);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
