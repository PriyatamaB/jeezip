package com.backend.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.backend.pojo.Contact;

@Repository
public class ContactDaoImpl implements ContactDao 
{
	@Autowired
	private SessionFactory factory;

	@Override
	public List<Contact> getAllContact() {
		Session session = factory.getCurrentSession();
		String sql = "select c from  Contact c";
		Query query = session.createQuery(sql);
		return query.list();
	}

	@Override
	public void addContact(Contact contact) {
		factory.getCurrentSession().save(contact);
		
	}

	@Override
	public void deleteContact(int id) {
		Contact contact = (Contact) factory.getCurrentSession().get(Contact.class, new Integer(id));
		factory.getCurrentSession().delete(contact);
	}

	@Override
	public void updateContact(Contact contact) {
		System.out.println("inside update dao::"+contact);
		factory.getCurrentSession().saveOrUpdate(contact);
	}

	@Override
	public Contact getContactById(int id) {
		return (Contact) factory.getCurrentSession().get(Contact.class, new Integer(id));
	}

}
