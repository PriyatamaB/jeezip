package com.backend.dao;

import java.util.List;

import com.backend.pojo.Contact;

public interface ContactDao {
	
	public List<Contact> getAllContact();
	public void addContact(Contact contact);
	public void deleteContact(int id);
	public void updateContact(Contact contact);
	public Contact getContactById(int id);

}
