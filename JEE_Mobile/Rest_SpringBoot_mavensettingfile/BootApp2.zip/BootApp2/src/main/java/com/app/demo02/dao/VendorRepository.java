package com.app.demo02.dao;

import org.springframework.data.repository.CrudRepository;

import com.app.demo02.pojo.Vendor;


public interface VendorRepository extends CrudRepository<Vendor,Integer>
{
	public Vendor findByName(String name);
}
