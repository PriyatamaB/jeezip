package com.app.demo02.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="TB_VENDOR")
public class Vendor 
{
	private Integer id;
	private String name,email,password,role,city,phone;
	private double regAmt;
	private Date regDate;
	private List<BankAccount> accList = new ArrayList<>();
	
	public Vendor() {
		System.out.println("Inside vendor cons");
	}

	public Vendor(String name, String email, String password, String role, String city, String phone, double regAmt,
			Date regDate) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.role = role;
		this.city = city;
		this.phone = phone;
		this.regAmt = regAmt;
		this.regDate = regDate;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="V_ID")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name="V_NAME")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name="V_EMAIL",unique=true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name="PASSWORD",length=10)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name="V_ROLE")
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Column(name="V_CITY")
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name="V_PHONE",length=13,unique=true)
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Column(name="V_REG_AMT",columnDefinition="double(8,1)")
	public double getRegAmt() {
		return regAmt;
	}

	public void setRegAmt(double regAmt) {
		this.regAmt = regAmt;
	}

	@Column(name="V_REG_DATE")
	@Temporal(TemporalType.DATE)
	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	@OneToMany(mappedBy="vendor",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	public List<BankAccount> getAccList() {
		return accList;
	}

	public void setAccList(List<BankAccount> accList) {
		this.accList = accList;
	}

	public void addAccount(BankAccount acc)
	{
		this.accList.add(acc);
		acc.setVendor(this);
	}
	
	public void removeAccount(BankAccount acc)
	{
		this.accList.remove(acc);
		acc.setVendor(null);
	}
	@Override
	public String toString() {
		return "Vendor [vid=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", role="
				+ role + ", city=" + city + ", phone=" + phone + ", regAmt=" + regAmt + ", regDate=" + regDate + "]";
	}
}
