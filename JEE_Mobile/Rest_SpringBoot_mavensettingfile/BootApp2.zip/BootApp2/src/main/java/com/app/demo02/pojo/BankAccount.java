package com.app.demo02.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TB_ACCOUNTS")
public class BankAccount 
{
	private Integer accId;
	private String accType;
	private double balance;
	private Vendor vendor;
	
	public BankAccount() {
		System.out.println("Inside Account cons");
	}

	public BankAccount(String accType, double balance) {
		super();
		this.accType = accType;
		this.balance = balance;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ACC_ID")
	public Integer getAccId() {
		return accId;
	}

	public void setAccId(Integer accId) {
		this.accId = accId;
	}

	@Column(name="ACC_TYPE")
	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	@Column(name="ACC_BAL",columnDefinition="double(9,2)")
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@ManyToOne
	@JoinColumn(name="V_ID")
	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}

	@Override
	public String toString() {
		return "BankAccount [accId=" + accId + ", accType=" + accType + ", balance=" + balance + "]";
	}
	
}
