package com.app.demo02.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.demo02.dao.VendorRepository;
import com.app.demo02.pojo.Vendor;


@Transactional
@Service
public class VendorServiceImpl implements VendorService 
{
	@Autowired
	private VendorRepository venDao;
	
	
	@Override
	public Iterable<Vendor> getAllVendors()
	{
		return venDao.findAll();
	}


	@Override
	public Vendor addNewVendor(Vendor v) 
	{
		//venDao.
		return venDao.save(v);
		
	}


	@Override
	public Optional<Vendor> getVendorDetails(Integer id) {
		System.out.println("----------------"+venDao.existsById(id));
		return venDao.findById(id);
		
	}


	@Override
	public Vendor findByName(String name) {
		return venDao.findByName(name);
	}

}
