package com.app.demo02;

import java.text.SimpleDateFormat;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner.Mode;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.app.demo02.pojo.BankAccount;
import com.app.demo02.pojo.Vendor;
import com.app.demo02.service.VendorService;



@SpringBootApplication
public class BootApp2Application implements CommandLineRunner 
{
	@Autowired
	private VendorService service;
	
	private static Scanner sc = new Scanner(System.in);
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	public static void main(String[] args) 
	{
		SpringApplication app = new SpringApplication(BootApp2Application.class);
		app.setBannerMode(Mode.OFF);
		app.run(args);
	}

	@Override
	public void run(String... args) throws Exception 
	{
		int ch;
		while((ch = BootApp2Application.menuList())!=0)
		{
			switch (ch) 
			{
			case 1:
				System.out.println("Enter Vendor details ::  name,  email,  password,  role,  city,  phone,  regAmt, regDate");
				Vendor v = new Vendor(sc.next(), sc.next(), sc.next(), sc.next(), sc.next(), sc.next(), sc.nextDouble(), sdf.parse(sc.next()));
				System.out.println("Enter Account Details :: accType, balance");
				BankAccount a1 = new BankAccount(sc.next(), sc.nextDouble()); 
				//v.addAccount(a1);
				System.out.println("Enter Account Details :: accType, balance");
				BankAccount a2 = new BankAccount(sc.next(), sc.nextDouble());
				//v.addAccount(a2);
				System.out.println(service.addNewVendor(v));
				break;
			case 2:
				service.getAllVendors().forEach(System.out::println);
				break;
			case 3:
				System.out.println("Enete Vendor ID ::");
				Optional<Vendor> v1 = service.getVendorDetails(sc.nextInt());
				if(v1.isPresent())
					System.out.println("Vendor Details ::"+v1.get());
				else
					System.out.println("Details Not found");
				break;
			case 4:
				System.out.println("Enter name::");
				System.out.println(service.findByName(sc.next()));
				break;
			default:
				break;
			}
		}
		
	}
	
	public static int menuList()
	{
		System.out.println("0.EXIT");
		System.out.println("1.ADD NEW VENDOR");
		System.out.println("2.GET ALL VENDOR");
		System.out.println("3.GET VENDOR DETAILS BY VID");
		System.out.println("4.GET VENDOR DETAILS BY NAME");
		return sc.nextInt();
	}
}

