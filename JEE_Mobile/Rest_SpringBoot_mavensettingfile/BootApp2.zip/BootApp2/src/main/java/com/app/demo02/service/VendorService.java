package com.app.demo02.service;

import java.util.Optional;

import com.app.demo02.pojo.Vendor;

public interface VendorService 
{
	public Vendor addNewVendor(Vendor v);
	public Iterable<Vendor> getAllVendors();
	public Optional<Vendor> getVendorDetails(Integer id);
	public Vendor findByName(String name);
	
}
