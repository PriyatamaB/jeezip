package com.app.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/test")
public class TestController {
	public TestController() {
		System.out.println("in constr "+getClass().getName());
	}
	@GetMapping("/hi") //=@RequestMapping(method=get)
	public String testMe(Model map)
	{
		//map.addAttribute("date",,new Date());
		map.addAttribute(new Date());//using generated model attr name
		System.out.println(map);
		return "/abc/hello";
	}
	
}
