package com.app.pojos;
import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="vendors")
public class Vendor {
	private Integer id;
	private String name="some name",email="some email",city,phoneNo,password,role;
	private double regAmount;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date regDate;
	//one--many bi dir asso between entities
	private List<BankAccount> accts=new ArrayList<>();
	public Vendor() {
		System.out.println("in vendor constr");
	}
	public Vendor(String name, String email, String city, String phoneNo, String password, String role,
			double regAmount, Date regDate) {
		super();
		this.name = name;
		this.email = email;
		this.city = city;
		this.phoneNo = phoneNo;
		this.password = password;
		this.role = role;
		this.regAmount = regAmount;
		this.regDate = regDate;
	}
	
	public Vendor(Integer id, String name, String email, String city, String phoneNo) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.city = city;
		this.phoneNo = phoneNo;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Column(length=20)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(length=20,unique=true)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(length=20)
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Column(length=10)
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Column(length=20)
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Column(length=10)
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Column(name="reg_amt",columnDefinition="double(8,1)")
	public double getRegAmount() {
		return regAmount;
	}
	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}
	@Column(name="reg_date")
	@Temporal(TemporalType.DATE)
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	@OneToMany(mappedBy="owner",cascade=CascadeType.ALL)
	public List<BankAccount> getAccts() {
		return accts;
	}
	public void setAccts(List<BankAccount> accts) {
		this.accts = accts;
	}
	//convenience methods
	public void addAccount(BankAccount a)
	{
		accts.add(a);
		a.setOwner(this);
	}
	public void removeAccount(BankAccount a)
	{
		accts.remove(a);
		a.setOwner(null);
	}
	
	@Override
	public String toString() {
		return "Vendor [id=" + id + ", name=" + name + ", email=" + email + ", city=" + city + ", phoneNo=" + phoneNo
				+ ", password=" + password + ", role=" + role + ", regAmount=" + regAmount + ", regDate=" + regDate
				+ "]";
	}
	

}
