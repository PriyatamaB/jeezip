package com.app.dao;

import java.util.List;

import com.app.pojos.Vendor;

public interface VendorManagementDao {
	List<Vendor> listVendors();
	Vendor authenticateUser(String email,String password);
	String registerVendor(Vendor transientVendor);
}
