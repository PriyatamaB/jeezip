package com.app.controller;

import javax.persistence.NoResultException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Vendor;
import com.app.service.VendorManagementService;

@Controller
@RequestMapping("/vendor")
public class VendorController {
	// dependency
	@Autowired
	private VendorManagementService service;

	public VendorController() {
		System.out.println("in constr " + getClass().getName());
	}

	@GetMapping("/list")
	public String listVendors(Model map) {
		map.addAttribute("vendor_list", service.listVendors());
		return "/vendor/list";
	}

	@GetMapping("/login")
	public String showLoginForm() {
		System.out.println("in show login form");
		return "/vendor/login";
	}

	@PostMapping("/login")
	public String processLoginForm(@RequestParam String email,
			@RequestParam String pass, Model map, HttpSession hs,RedirectAttributes flashMap) {
		System.out.println("in process login form " + email + " " + pass);
		Vendor v=null;
		try {
			v = service.authenticateUser(email, pass);
			//valid login
			if(v.getRole().equals("vendor")) {
				//add validated user dtls under session scope
				hs.setAttribute("user_dtls", v);//v ---DETACHED
				flashMap.addFlashAttribute("status","Vendor Login Successful");
				return "redirect:/vendor/details";
			}
			//admin login
			flashMap.addFlashAttribute("status","Admin Login Successful");
			return "redirect:/vendor/list";
				
		} catch (NoResultException e) {
			// invalid login --forward clnt to login form & with err mesg
			map.addAttribute("status", "Invalid Login , Pls Retry...");
			return "/vendor/login";
		}

	
	}
	@GetMapping("/details")
	public String showDetails() {
		System.out.println("in show details");
		return "/vendor/details";
	}
	@GetMapping("/logout")
	public String logMeOut(HttpSession hs,Model map,HttpServletRequest request,HttpServletResponse resp) {
		System.out.println("in log out ");
		map.addAttribute("user_info", hs.getAttribute("user_dtls"));
		//invalidating Http Session
		hs.invalidate();
		resp.setHeader("refresh", "5;url="+request.getContextPath());
		return "/vendor/logout";
	}
	//req handling method for showing reg form
	@GetMapping("/register")
	public String showRegForm(Vendor v)
	{
		//Vendor v=new Vendor(); map.addAttribute("vendor",v);
		System.out.println("in show reg form "+v);
		return "/vendor/register";
	}
	//req handling method for processing reg form
		@PostMapping("/register")
		public String processRegForm(Vendor v,RedirectAttributes flashMap)
		{
			//Vendor v=new Vendor(); map.addAttribute("vendor",v);
			System.out.println("in process reg form "+v);
			flashMap.addFlashAttribute("status",service.registerVendor(v));
			return "redirect:/vendor/list";
		}
	
	

}
