package com.app.controller;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.service.UserService;
import com.app.service.UserServiceImpl;

import pojos.User;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired //by type
	private UserService service;
	
	public UserController() {
		System.out.println("in cnstr of " + getClass().getName()+" "+service);
	}
	@PostConstruct
	public void init()
	{
		System.out.println("in init "+service);
	}
	// request handling method ---to show login form
	@GetMapping("/login")
	public String showLoginForm()
	{
		System.out.println("in show login form");
		return "/user/login";
	}
	//request hadnling method for processing form
	@PostMapping("/login")
	public String processLoginForm(@RequestParam String email,@RequestParam String pass,Model map)
	{
		System.out.println("in process login form "+service);
		System.out.println(email +" "+pass);
		User user=service.authenticateUser(email, pass);
		if(user == null)
			return "/user/login";
		//valid login --chk role
		if(user.getRole().equals("admin"))
			return "/admin/list";
		//vendor
		map.addAttribute("user_dtls",user);
		return "/user/details";
	}

}
