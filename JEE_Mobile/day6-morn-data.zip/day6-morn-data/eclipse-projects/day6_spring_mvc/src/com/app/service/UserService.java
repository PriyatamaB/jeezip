package com.app.service;

import pojos.User;

public interface UserService {
	User authenticateUser(String email,String pass);
}
