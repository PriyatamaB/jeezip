package com.app.service;

import java.util.Date;
import java.util.HashMap;

import org.springframework.stereotype.Service;

import pojos.User;

@Service("user_service")
public class UserServiceImpl implements UserService {
	private HashMap<String, User> users;

	public UserServiceImpl() {
		System.out.println("in cnstr of " + getClass().getName());
		// create empty map
		users = new HashMap<>();
		users.put("abc@gmail", new User(1, "abc", "abc@gmail", "1234", "admin", 500, new Date()));
		users.put("abc2@gmail", new User(2, "abc2", "abc2@gmail", "2345", "vendor", 1500, new Date()));

	}

	@Override
	public User authenticateUser(String email, String pass) {
		System.out.println("in service : auth user "+email+" "+pass);
		User u = users.get(email);
		if (u != null)
			if (u.getPassword().equals(pass))
				return u;
		return null;
	}

}
