package com.app.controller;

import java.util.Arrays;
import java.util.Date;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	public HelloController() {
		System.out.println("in constr of "+getClass().getName());
	}
	@PostConstruct
	public void anyName()
	{
		System.out.println("in init");
	}
	@RequestMapping("/hello")
	public String sayHello()
	{
		System.out.println("in say hello");
		return "welcome";
	}
	@RequestMapping("/hello2")
	public ModelAndView sayHello2()
	{
		System.out.println("in say hello2");
		return new ModelAndView("welcome","server_dt", new Date());
	}
	@RequestMapping("/hello3")
	public String sayHello3(Model map)
	{
		System.out.println("in say hello3 "+map);
		map.addAttribute("server_dt", new Date());
		map.addAttribute("num_list", Arrays.asList(1,2,3,4,5));
		System.out.println("model "+map);
		return "welcome";
	}
	

}
