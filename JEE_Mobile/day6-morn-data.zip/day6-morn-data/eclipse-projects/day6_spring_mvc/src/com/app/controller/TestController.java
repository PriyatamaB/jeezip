package com.app.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/test")
public class TestController {
	public TestController() {
		System.out.println("in constr of " + getClass().getName());
	}

	@GetMapping("/hello4")
	public String testReqParams(@RequestParam String product_nm, @RequestParam(name = "price") double price123,
			@RequestParam Date exp_date,Model map) {
		System.out.println("in test req params "+map);
		map.addAttribute("dt", exp_date);
		map.addAttribute("nm", product_nm);
		map.addAttribute("pr_price", price123);
		return "/test/display";
	}

}
