package pojos;
import javax.persistence.*;

@Entity
@Table(name="bank_accts")
public class BankAccount {
	private Integer acctId;
	private String acType;
	private double balance;
	//mapping related propery
	private Vendor owner;
	public BankAccount() {
		System.out.println("in acct constr");
	}
	
	public BankAccount(String acType, double balance) {
		super();
		this.acType = acType;
		this.balance = balance;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer getAcctId() {
		return acctId;
	}

	public void setAcctId(Integer acctId) {
		this.acctId = acctId;
	}
	@ManyToOne
	@JoinColumn(name="vendor_id")
	public Vendor getOwner() {
		return owner;
	}

	public void setOwner(Vendor owner) {
		this.owner = owner;
	}
	@Column(name="ac_type",length=10)
	public String getAcType() {
		return acType;
	}
	public void setAcType(String acType) {
		this.acType = acType;
	}
	@Column(columnDefinition="double(8,2)")
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	@Override
	public String toString() {
		return "BankAccount [acctId=" + acctId + ", acType=" + acType + ", balance=" + balance + "]";
	}
	

}
