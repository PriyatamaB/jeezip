package beans;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import dao.VendorDaoImpl;
import pojos.BankAccount;
import pojos.Vendor;

public class VendorBean {
	private static SimpleDateFormat sdf;
	private VendorDaoImpl dao;
	// props --clnt' conv state
	private int vid;
	private String ac_type;
	private double bal;
	private String name, email, city, phoneNo, password, role;
	private double regAmt;
	private String registerDate;
	// property to hold selected vendor dtls
	private Vendor dtls;
	// property to hold status mesg
	private String status;
	// static init block
	static {
		sdf = new SimpleDateFormat("yyyy-MM-dd");
	}

	public VendorBean() {
		dao = new VendorDaoImpl();
	}

	// B.L method to fetch all vendor details
	public List<Vendor> listVendors() {
		System.out.println("in jb : list vendors");
		return dao.listVendors();
	}

	// WC performs string ---> int conversion
	public void setVid(int vid) {
		this.vid = vid;
	}

	public Vendor getDtls() {
		return dtls;
	}

	public void setAc_type(String ac_type) {
		this.ac_type = ac_type;
	}

	public void setBal(double bal) {
		this.bal = bal;
	}
	// setters for setting the state of JB as per req params

	// B.L method to fetch details about selected vendor
	public void fetchDetails() {
		System.out.println("in jb : fetch dtls");
		dtls = dao.getVendorDetails(vid);
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void setRegAmt(double regAmt) {
		this.regAmt = regAmt;
	}

	public void setRegisterDate(String registerDate) {
		this.registerDate = registerDate;
	}

	public String getStatus() {
		return status;
	}

	// B.L method to create a/c
	public String createAccount() {
		System.out.println("jb : create a/c");
		// create transient a/c object
		BankAccount a = new BankAccount(ac_type, bal);
		// pass it to dao layer for persistence

		status = dao.createAccount(dtls, a);
		return "details";// navigational outcome (name of the next page)
	}

	// B.L method to delete vendor
	public String deleteVendor() {
		System.out.println("jb : del vendor " + dtls);
		dtls = dao.getVendorDetails(vid);
		System.out.println("dtls again " + dtls);
		status = dao.deleteVendor(dtls);
		return "list";
	}

	// B.L method for vendor reg
	public String registerVendor() throws Exception {
		System.out.println("jb : reg vendor");
		// create transient vendor
		Vendor v = new Vendor(name, email, city, phoneNo, 
				password, role, regAmt, sdf.parse(registerDate));
		// give it to DAO for persistence
		status=dao.registerVendor(v);
		return "list";
	}

}
