package tester;

//
import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CourseManagementImpl;
import pojos.Course;
import pojos.Student;

public class StudentAdmission {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			System.out.println("Enter course id & student's email");
			int id = sc.nextInt();// course id
			Student s = new Student(sc.next());
			CourseManagementImpl dao = new CourseManagementImpl();
			System.out.println(dao.registerStudentToCourse(id, s));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
