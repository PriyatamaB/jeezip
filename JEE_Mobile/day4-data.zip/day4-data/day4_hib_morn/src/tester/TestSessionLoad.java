package tester;

//
import static utils.HibernateUtils.*;


import java.util.Scanner;

import org.hibernate.*;


import pojos.Course;


public class TestSessionLoad {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			System.out.println("Enter course id");
			Course c=null;
			int id=sc.nextInt();
			Session hs = getSf().getCurrentSession();
			Transaction tx = hs.beginTransaction();
			try {
				c=hs.load(Course.class,id);//c --by def rets un-inited proxy
				c.getFees();//non id getter
				System.out.println(c.getClass().getName());
				tx.commit();
			} catch (HibernateException e) {
				if (tx != null)
					tx.rollback();
				throw e;
			}
			//c --detached
			System.out.println("course details "+c);//trying to access un-inited proxy=un fecthed data --outside session scope
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
