package tester;

//
import static utils.HibernateUtils.*;


import java.util.Scanner;

import org.hibernate.*;


import pojos.Course;


public class TestSessionGet {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			System.out.println("Enter course id");
			Course c=null;
			int id=sc.nextInt();
			Session hs = getSf().getCurrentSession();
			Transaction tx = hs.beginTransaction();
			try {
				c=hs.get(Course.class,id);//c null OR PERSISTENT
				tx.commit();
			} catch (HibernateException e) {
				if (tx != null)
					tx.rollback();
				throw e;
			}
			//c --detached
			System.out.println("course details "+c);
			System.out.println(c.getClass().getName());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
