package tester;

//
import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CourseManagementImpl;
import pojos.AdharCard;
import pojos.Course;
import pojos.Student;

public class LinkAdharCard {

	public static void main(String[] args) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			System.out.println("Enter student id ,adhar card number n date");

			CourseManagementImpl dao = new CourseManagementImpl();
			System.out.println(dao.linkStudentAdharCard(sc.nextInt(), new AdharCard(sc.next(), sdf.parse(sc.next()))));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
