package dao;

import pojos.AdharCard;
import pojos.Course;
import pojos.Student;

public interface CourseManagementDao {
	String launchCourseWithStudents(Course c);
	String registerStudentToCourse(int courseId,Student s);
	Course getCourseDetails(String name);
	Course getCourseDetailsWithStudents(String name);
	String linkStudentAdharCard(int sid,AdharCard card);

}
