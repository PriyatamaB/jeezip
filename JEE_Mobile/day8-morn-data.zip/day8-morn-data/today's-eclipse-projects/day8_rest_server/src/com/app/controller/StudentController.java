package com.app.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.StudentDao;

import pojos.Student;

@RestController
@RequestMapping("/students")
public class StudentController {
	// dependency
	@Autowired
	private StudentDao dao;

	@PostConstruct
	public void init() {
		System.out.println("in init " + dao);
	}

	// get student resource
	@GetMapping("/{sid}")
	public Student getStudentDetails(@PathVariable int sid) {
		System.out.println("srvr : get stud dtls " + sid);
		return dao.getStudentDetails(sid);
	}

	// get all student dtls
	@GetMapping
	public List<Student> getAllStudentDetails() {
		System.out.println("srvr : get stud dtls ");
		return dao.getAllStudentDetails();
	}

	// create new student resource
	@PostMapping
	public String registerStudent(@RequestBody Student s) {
		System.out.println("srvr : reg student  " + s);
		return dao.registerStudent(s);
	}

	// delete student record
	@DeleteMapping("/{sid}")
	public String deleteStudentDetails(@PathVariable int sid) {
		System.out.println("srvr : del stud dtls " + sid);
		return dao.deleteStudent(dao.getStudentDetails(sid));
	}
	
	// update existing student resource
		@PutMapping
		public String updateStudent(@RequestBody Student s) {
			System.out.println("srvr : update student  " + s);
			return dao.updateStudent(s);
					
		}
	
	

}
