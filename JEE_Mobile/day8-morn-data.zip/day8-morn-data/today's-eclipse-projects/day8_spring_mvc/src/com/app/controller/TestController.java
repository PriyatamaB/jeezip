package com.app.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pojos.User;

@Controller
@RequestMapping("/test")
public class TestController {
	public TestController() {
		System.out.println("in constr of " + getClass().getName());
	}

	@GetMapping("/test1")
	public @ResponseBody String testMe1() {
		System.out.println("in test me1");
		return "hello";
	}

	@GetMapping("/test2")
	public @ResponseBody List<User> testMe2() {
		System.out.println("in test me2");
		return Arrays.asList(new User(1, "abc", "abc@gmail", "1223", "cust", 500, new Date()),
				new User(2, "abc2", "abc2@gmail", "3223", "cust", 1500, new Date()));
	}

	// URI template variables
	@GetMapping("/test3/{product_name}/{price}/{exp_date}")
	public  String testMe3(@PathVariable(name = "product_name") String nm, @PathVariable double price,
			@PathVariable @DateTimeFormat(pattern="dd-MM-yyyy") Date exp_date,Model map) {
		System.out.println("in test me3");
		map.addAttribute("product_dtls", nm+" @ . "+price+" expires on "+exp_date);
		return "/test/display";
	}

}
