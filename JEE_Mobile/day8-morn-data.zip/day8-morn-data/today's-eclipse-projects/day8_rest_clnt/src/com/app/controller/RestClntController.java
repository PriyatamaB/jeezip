package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import dto.StudentDTO;

@Controller
@RequestMapping("/student")
public class RestClntController {
	public RestClntController() {
		System.out.println("in constr " + getClass().getName());
	}
	@GetMapping("/fetch_dtls/{stud_id}")
	public String fetchStudentDetails(@PathVariable int stud_id,RestTemplate template,Model map) {
		System.out.println("in rest clnt : fetch "+stud_id);
		String url="http://localhost:8080/day8_rest_server/students/{student_id}";
		//invoke REST API 
		StudentDTO s=template.getForObject(url,StudentDTO.class,stud_id);
		map.addAttribute(s);
		return "/student/details";
		
	}

}
