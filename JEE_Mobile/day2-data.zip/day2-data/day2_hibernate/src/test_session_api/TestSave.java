package test_session_api;

//
import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.*;
import pojos.Customer;

public class TestSave {

	public static void main(String[] args) {
		// SDF
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			System.out.println("Enter customer details : amt nm em role pass dt");
			// create transient obj
			Customer c = new Customer(sc.nextDouble(), sc.next(), sc.next(), sc.next(), sc.next(),
					sdf.parse(sc.next()));
			c.setId(123);
			Session hs=getSf().getCurrentSession();
			//tx
			Transaction tx=hs.beginTransaction();
			try {
				hs.persist(c);
				tx.commit();
			}catch (HibernateException e) {
				if(tx != null)
					tx.rollback();
				throw e;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
