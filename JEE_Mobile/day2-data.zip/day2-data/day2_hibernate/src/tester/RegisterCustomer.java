package tester;

//
import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.*;
import pojos.Customer;

public class RegisterCustomer {

	public static void main(String[] args) {
		// SDF
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			System.out.println("Enter customer details : amt nm em role pass dt");
			// create transient obj
			Customer c = new Customer(sc.nextDouble(), sc.next(), sc.next(), sc.next(), sc.next(),
					sdf.parse(sc.next()));
			System.out.println(new BookShopDaoImpl().registerCustomer(c));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
