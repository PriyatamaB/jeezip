package tester;

//
import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.*;
import pojos.Customer;

public class DeleteCustomerDetails {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			System.out.println("Enter customer id for removal");
			System.out.println(new BookShopDaoImpl().deleteCustomerDetails(sc.nextInt()));
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
