package tester;

//
import static utils.HibernateUtils.*;

import org.hibernate.SessionFactory;

import dao.*;

public class ListAllCustomers {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf()) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			new BookShopDaoImpl().getAllCustomers().forEach(System.out::println);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
