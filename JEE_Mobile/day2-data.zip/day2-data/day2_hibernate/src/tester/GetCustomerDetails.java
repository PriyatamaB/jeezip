package tester;

//
import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.*;
import pojos.Customer;

public class GetCustomerDetails {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			System.out.println("Enter customer id");
			Customer c = new BookShopDaoImpl().getCustomerDetails(sc.nextInt());
			System.out.println(c == null ? "Invalid customer ID" : c);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
