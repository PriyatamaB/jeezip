package tester;

//
import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.*;

public class UpdateCustomers2 {

	public static void main(String[] args) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("SF created...hibernate up n running!!!!!!");
			System.out.println("Enter reg date n discount");
			System.out.println("Update count "+new BookShopDaoImpl().
			applyDiscount2(sdf.parse(sc.next())
					, sc.nextDouble()));
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
