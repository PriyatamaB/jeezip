package dao;

import pojos.Customer;
import org.hibernate.*;
import static utils.HibernateUtils.getSf;

import java.util.Date;
import java.util.List;

public class BookShopDaoImpl implements BookShopDao {

	@Override
	public String registerCustomer(Customer c) {
		// hs --get current session
		Session hs = getSf().getCurrentSession();
		// Session hs2=getSf().getCurrentSession();
		// System.out.println(hs==hs2);
		// tx
		Transaction tx = hs.beginTransaction();
		System.out.println("after begin tx " + hs.isConnected() + " " + hs.isOpen());
		try {
			// c-- TRANSIENT
			hs.save(c); // PERSISTENT
			// System.out.println("Press enter to continue");
			// System.in.read();
			tx.commit();// automatic dirty checking ---insert query
			// L1 cache destroyed , cn rets to the pool, session closed
			System.out.println("after commit " + hs.isConnected() + " " + hs.isOpen());
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		/*
		 * catch (Exception e) { e.printStackTrace(); }
		 */

		return "Customer reged succesfully Id " + c.getId();
	}

	@Override
	public Customer getCustomerDetails(int id) {
		Customer c = null;
		// hs
		Session hs = getSf().getCurrentSession();
		// tx
		Transaction tx = hs.beginTransaction();
		try {
			c = hs.get(Customer.class, id);
			// c=hs.get(Customer.class,id);
			// c=hs.get(Customer.class,id);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return c;
	}

	@Override
	public List<Customer> getAllCustomers() {
		List<Customer> l1 = null;
		String jpql = "select c from Customer c";
		Session hs = getSf().getCurrentSession();
		// tx
		Transaction tx = hs.beginTransaction();
		try {
			l1 = hs.createQuery(jpql, Customer.class).getResultList();
			// l1 --- list of PERSISTENT pojos
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return l1;// l1 --- list of DETACHED pojos

	}

	@Override
	public List<Customer> getCustomersByCriteria(String role1, Date regDate1) {
		List<Customer> l1 = null;
		String jpql = "select c from Customer c where c.role = :rl and c.regDate > :dt";
		Session hs = getSf().getCurrentSession();
		// tx
		Transaction tx = hs.beginTransaction();
		try {
			l1 = hs.createQuery(jpql, Customer.class).setParameter("rl", role1).setParameter("dt", regDate1)
					.getResultList();
			// l1 --- list of PERSISTENT pojos
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return l1;// l1 --- list of DETACHED pojos
	}

	@Override
	public List<Customer> applyDiscount(Date regDate1, double discount) {
		List<Customer> l1 = null;
		String jpql = "select c from Customer c where c.regDate < :dt";
		Session hs = getSf().getCurrentSession();
		// tx
		Transaction tx = hs.beginTransaction();
		try {
			l1 = hs.createQuery(jpql, Customer.class).setParameter("dt", regDate1).getResultList();
			for (Customer c : l1)
				c.setRegAmount(c.getRegAmount() - discount);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		for (Customer c : l1)
			c.setRegAmount(c.getRegAmount() - discount);

		return l1;
	}

	@Override
	public int applyDiscount2(Date regDate1, double discount) {
		int updateCount = 0;
		String jpql = "update Customer c set c.regAmount = c.regAmount-:disc where c.regDate < :dt";
		Session hs = getSf().getCurrentSession();
		// tx
		Transaction tx = hs.beginTransaction();
		try {
			updateCount = hs.createQuery(jpql).setParameter("disc", discount).setParameter("dt", regDate1)
					.executeUpdate();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return updateCount;
	}

	@Override
	public String deleteCustomerDetails(int custId) {
		String mesg = "Customer deletion failed : invalid ID";
		// hs
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			// get persistent pojo ref
			Customer c = hs.get(Customer.class, custId);
			if (c != null) {
				// c --- persistent
				hs.delete(c);// marked for removal
				mesg = "Customer with ID " + c.getId() + " deleted successfully...";
			}
			tx.commit();// delete , l1 destroyed , session close , cn rets to
						// pool
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}
