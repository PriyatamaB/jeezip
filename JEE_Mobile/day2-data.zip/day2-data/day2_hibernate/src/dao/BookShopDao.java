package dao;

import java.util.Date;
import java.util.List;

import pojos.Customer;

public interface BookShopDao {
	//customer reg
	String registerCustomer(Customer c);
	Customer getCustomerDetails(int id);
	List<Customer> getAllCustomers();
	List<Customer> getCustomersByCriteria(String role,Date regDate);
	List<Customer> applyDiscount(Date regDate, double discount);
	int applyDiscount2(Date regDate, double discount);
	String deleteCustomerDetails(int custId);

}
