package pojos;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name="my_customers")
public class Customer {
	
	private Integer id;
	private double regAmount;
	private String name,email,role,password;
	private Date regDate;
	public Customer() {
		System.out.println("in constr of "+getClass().getName());
	}
	
	public Customer(double regAmount, String name, String email, String role, String password, Date regDate) {
		super();
		this.regAmount = regAmount;
		this.name = name;
		this.email = email;
		this.role = role;
		this.password = password;
		this.regDate = regDate;
	}

	//ALL g/s
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Column(name="deposit_amt")
	public double getRegAmount() {
		return regAmount;
	}
	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(unique=true)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="reg_date")
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", regAmount=" + regAmount + ", name=" + name + ", email=" + email + ", role="
				+ role + ", password=" + password + ", regDate=" + regDate + "]";
	}
	

}
