package beans;

import java.util.List;

import dao.VendorDaoImpl;
import pojos.BankAccount;
import pojos.Vendor;

public class VendorBean {
	private VendorDaoImpl dao;
	//props --clnt' conv state
	private int vid;
	private String ac_type;
	private double bal;
	//property to hold selected vendor dtls
	private Vendor dtls;
	public VendorBean() {
		dao=new VendorDaoImpl();
	}
	//B.L method to fetch all vendor details
	public List<Vendor> listVendors()
	{
		System.out.println("in jb : list vendors");
		return dao.listVendors();
	}
	//WC performs string ---> int conversion
	public void setVid(int vid) {
		this.vid = vid;
	}
	
	public Vendor getDtls() {
		return dtls;
	}
	
	public void setAc_type(String ac_type) {
		this.ac_type = ac_type;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	//B.L method to fetch details about selected vendor
	public void fetchDetails()
	{
		System.out.println("in jb : fetch dtls");
		dtls=dao.getVendorDetails(vid);
	}
	//B.L method to create a/c
	public String createAccount()
	{
		//create transient a/c object 
		BankAccount a=new BankAccount(ac_type,bal);
		//pass it to dao layer for persistence
		
		return dao.createAccount(dtls,a);
	}

}
