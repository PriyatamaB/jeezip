package dao;

import java.util.List;

import org.hibernate.*;

import static utils.HibernateUtils.*;

import pojos.BankAccount;
import pojos.Vendor;

public class VendorDaoImpl implements VendorDao {

	@Override
	public List<Vendor> listVendors() {
		List<Vendor> list = null;
		String jpql = "select new Vendor(id,name,email,city,phoneNo) from Vendor v";
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			list = hs.createQuery(jpql, Vendor.class).getResultList();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return list;
	}

	@Override
	public Vendor getVendorDetails(int id2) {
		Session hs = getSf().getCurrentSession();
		Vendor v = null;
		String jpql = "select v from Vendor v left outer join fetch v.accts where v.id = :id1";
		Transaction tx = hs.beginTransaction();
		try {
			v = hs.createQuery(jpql, Vendor.class).setParameter("id1", id2).getSingleResult();
			// v --- persistent
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return v;// v --- detached
	}

	@Override
	public String createAccount(Vendor detachedVendor, BankAccount transientAc) {
		String mesg = "A/C Creation failed";
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			//re attach detached POJO with L1 cache
			hs.update(detachedVendor);//detachedV --persistent
			System.out.println("HS contains "+hs.contains(detachedVendor));
			detachedVendor.addAccount(transientAc);
			tx.commit();
			mesg="A/C created successfully";
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}
