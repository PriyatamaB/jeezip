package dao;

import java.util.List;

import pojos.BankAccount;
import pojos.Vendor;

public interface VendorDao {
	List<Vendor> listVendors();
	Vendor getVendorDetails(int id);
	String createAccount(Vendor detachedVendor,BankAccount transientAc);

}
