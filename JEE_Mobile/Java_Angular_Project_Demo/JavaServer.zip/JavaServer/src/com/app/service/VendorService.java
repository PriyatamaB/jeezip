package com.app.service;

import java.util.List;

import com.app.pojo.BankAccount;
import com.app.pojo.Vendor;

public interface VendorService 
{
	public String registerVendor(Vendor v);
	public Vendor login(String email,String pass);
	public List<Vendor> listVendors();
	public List<BankAccount> listAccounts(Integer vid);
	public Vendor getVendorDetails(Integer vid);
	public void deleteVendor(Integer vid);
	public void createAccount(BankAccount acc);
	public void closeAccount(BankAccount acc);
	public BankAccount getAccount(Integer aid);
	public long generateAccountNo();
	public List<Long> getAccountNo();
	public BankAccount getAccountDetails(long accNo);
	public void sendSms(String user,String apiKey,String msg,String sender,String number,String type);
	public String getRandomString();
	public Vendor getBtPhoneNo(String phoneNo);
}
