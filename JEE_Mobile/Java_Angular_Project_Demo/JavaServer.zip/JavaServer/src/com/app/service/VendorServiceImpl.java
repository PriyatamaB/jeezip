package com.app.service;

import java.io.*;
import java.net.*;
import java.util.List;
import java.util.Random;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.app.daos.VendorDao;
import com.app.pojo.BankAccount;
import com.app.pojo.Vendor;

@Service
@Transactional
public class VendorServiceImpl implements VendorService 
{
	@Autowired
	private VendorDao dao;
	private Random random = new Random(); 

	@Override
	public String registerVendor(Vendor v) {
		return dao.registerVendor(v);
	}

	@Override
	public Vendor login(String email, String pass) {
		return dao.login(email, pass);
	}

	@Override
	public List<Vendor> listVendors() {
		return dao.listVendors();
	}

	@Override
	public List<BankAccount> listAccounts(Integer vid) {
		//return dao.listAccounts(vid);
		return null;
	}

	
	@Override
	public void deleteVendor(Integer vid) {
		dao.deleteVendor(dao.getVendorDetails(vid));
	}

	@Override
	public Vendor getVendorDetails(Integer vid) {
		return dao.getVendorDetails(vid);
	}

	@Override
	public void createAccount(BankAccount acc) {
		dao.createAccount(acc);
		
	}

	@Override
	public void closeAccount(BankAccount acc) {
		dao.closeAccount(acc);
		
	}

	@Override
	public BankAccount getAccount(Integer aid) {
		return dao.getAccount(aid);
	}

	@Override
	public long generateAccountNo()
	{
		
		long num = (long)random.nextInt(Integer.SIZE-1)+33001006000L;
	return num;
	}

	@Override
	public List<Long> getAccountNo() {
		return dao.getAccountNo();
	}

	@Override
	public BankAccount getAccountDetails(long accNo) {
		
		return dao.getAccountDetails(accNo);
	}

	@Override
	public void sendSms(String user, String apiKey, String msg, String sender, String number, String type) {
		URLConnection myURLConnection=null;
		URL myURL=null;
		BufferedReader reader=null;

		//encoding message 
		String encoded_message=URLEncoder.encode(msg);

		//Send SMS API
		String mainUrl="http://smshorizon.co.in/api/sendsms.php?";

		//Prepare parameter string 
		StringBuilder sbPostData= new StringBuilder(mainUrl);
		sbPostData.append("user="+user); 
		sbPostData.append("&apikey="+apiKey);
		sbPostData.append("&message="+encoded_message);
		sbPostData.append("&mobile="+number);
		sbPostData.append("&senderid="+sender);
		sbPostData.append("&type="+type);

		//final string
		mainUrl = sbPostData.toString();
		try
		{
		    //prepare connection
		    myURL = new URL(mainUrl);
		    myURLConnection = myURL.openConnection();
		    myURLConnection.connect();
		    reader= new BufferedReader(new InputStreamReader(myURLConnection.getInputStream()));
		    //reading response 
		    String response;
		    while ((response = reader.readLine()) != null) 
		    //print response 
		    System.out.println("-------------------------"+response);
		    
		    //finally close connection
		    reader.close();
		} 
		catch (IOException e) 
		{ 
			e.printStackTrace();
		} 
	}

	public String getRandomString() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder sb = new StringBuilder();
        Random rnd = new Random();
        while (sb.length() < 6) 
        { 
            int index = (int) (rnd.nextFloat() * chars.length());
            sb.append(chars.charAt(index));
        }
        String ranStr = sb.toString();
        return ranStr;

    }

	@Override
	public Vendor getBtPhoneNo(String phoneNo) {
		return dao.getBtPhoneNo(phoneNo);
	}
}
