package com.app.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="T_Accounts")
public class BankAccount 
{
	private Integer aId;
	private long accNo;
	private String type;
	private double balance;
	private Vendor vendor;
	
	public BankAccount() {
		// TODO Auto-generated constructor stub
	}

	public BankAccount(Integer aId, String type, double balance) {
		super();
		this.aId = aId;
		this.type = type;
		this.balance = balance;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="A_ID")
	public Integer getaId() {
		return aId;
	}

	public void setaId(Integer aId) {
		this.aId = aId;
	}

	@Column(name="V_TYPE")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Column(name="V_BALANCE")
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	

	@ManyToOne
	@JoinColumn(name="V_ID")
	//@JsonManagedReference
	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}

	@Column(name="ACC_NO",unique=true)
	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	@Override
	public String toString() {
		return "BankAccount [aId=" + aId + ", type=" + type + ", balance=" + balance + "]";
	}
}
