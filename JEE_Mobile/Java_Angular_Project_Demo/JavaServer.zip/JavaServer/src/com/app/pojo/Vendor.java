package com.app.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="T_Vendor")
public class Vendor 
{
	private Integer id;
	private String name;
	private String email;
	private String password;
	private String phoneNo;
	private Date bDate;
	private String role;
	private String imgPath;
	
	//@JsonIgnore
	private List<BankAccount> accounts = new ArrayList<>();
	
	public Vendor() {
		// TODO Auto-generated constructor stub
	}

	public Vendor(String name, String email, String password, String phoneNo, Date bDate,String role) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.phoneNo = phoneNo;
		this.bDate = bDate;
		this.role = role;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="V_ID")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name="V_NAME")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name="V_EMAIL", unique=true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name="PASSWORD",length=20)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name="V_PHONE",unique=true)
	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Temporal(TemporalType.DATE)
	@Column(name="V_BDATE")
	public Date getbDate() {
		return bDate;
	}

	public void setbDate(Date bDate) {
		this.bDate = bDate;
	}
	
	@OneToMany(mappedBy="vendor",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	//@JsonBackReference
	public List<BankAccount> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<BankAccount> accounts) {
		this.accounts = accounts;
	}

	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	public void addAccount(BankAccount acc)
	{
		accounts.add(acc);
		acc.setVendor(this);
	}
	
	public void removeAccount(BankAccount acc)
	{
		accounts.remove(acc);
		acc.setVendor(null);
	}
	
	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}
	
	@Override
	public String toString() {
		return "Vendor [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", phoneNo="
				+ phoneNo + ", bDate=" + bDate + ", role=" + role + ", imgPath=" + imgPath + "]";
	}
}
