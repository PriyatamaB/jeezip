package com.app.controller;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import com.app.pojo.BankAccount;
import com.app.pojo.Vendor;
import com.app.service.VendorService;
import models.AccountModel;
import models.VendorModel;

@CrossOrigin
@EnableWebMvc
@RestController
@RequestMapping("/vendor")
public class VendorManagementController 
{
	@Autowired
	private VendorService service;
	private String img;

	@CrossOrigin
	@PostMapping(value="/register")
	public ResponseEntity<Void> registerVendor(@RequestBody Vendor v)
	{
		System.out.println("From Session-------------------"+img);
		v.setImgPath(img);
		service.registerVendor(v);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}

	@CrossOrigin
	@PostMapping(value="/upload",headers="Accept=multipart/form-data")
	public void uploadImage(@RequestParam("file") MultipartFile file)
	{
		String uploadLocation = this.getClass().getResource("/../../uploads/").getPath();
		try 
		{
			File dest = new File(uploadLocation, file.getOriginalFilename());
			file.transferTo(dest);
			System.out.println(dest.getAbsolutePath());
			img=file.getOriginalFilename();
			System.out.println("-------------------------"+img);
		} 
		catch (Exception e) 
		{
			throw new RuntimeException("******File Upload Failed*******");
		}	
	}
	
	@CrossOrigin
	@PostMapping(value="/login",headers="Accept=application/json")
	public VendorModel loginVendor(@RequestBody Vendor vendor,HttpSession hs)
	{
		Vendor v = service.login(vendor.getEmail(), vendor.getPassword());
		hs.setAttribute("validVendor", v);
		return new VendorModel(v.getId(),v.getName(), v.getEmail(), v.getPhoneNo(), v.getbDate(),v.getImgPath(),v.getRole());
	}
	
	@GetMapping(value="/vList",headers="Accept=application/json")
	public List<VendorModel> listVendors()
	{
		List<VendorModel> vmList = new ArrayList<VendorModel>();
		List<Vendor>vList = service.listVendors();
		for (Vendor v : vList) 
		{
			vmList.add(new VendorModel(v.getId(),v.getName(),v.getEmail(),v.getPhoneNo(),v.getbDate(),v.getImgPath(),v.getRole()));
		}
		return vmList;
	}
	
	@DeleteMapping(value="/delete/{vid}",headers="Accept=application/json")
	public ResponseEntity<Void> deleteVendor(@PathVariable int vid)
	{
		service.deleteVendor(vid);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@GetMapping(value="/accounts/{vid}",headers="Accept=application/json")
	public List<AccountModel> getAccounts(@PathVariable int vid)
	{
		List<AccountModel> blList = new ArrayList<>();
		Vendor vendor = service.getVendorDetails(vid);
		for (BankAccount b : vendor.getAccounts()) {
			blList.add(new AccountModel(b.getaId(), b.getType(), b.getBalance(), b.getVendor().getId(),b.getAccNo()));
		}
		return blList;
	}
	
	@PostMapping(value="/createacc/{vid}",headers="Accept=application/json")
	public ResponseEntity<Void> createAccount(@RequestBody BankAccount acc,@PathVariable int vid)
	{
		
		long accNo = service.generateAccountNo();
		Vendor vendor = service.getVendorDetails(vid);
		acc.setVendor(vendor);
		acc.setAccNo(accNo);
		service.createAccount(acc);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	
	@DeleteMapping(value="/closeacc/{accNo}",headers="Accept=application/json")
	public ResponseEntity<Void> closeAccount(@PathVariable long accNo)
	{
		BankAccount acc = service.getAccountDetails(accNo);
		System.out.println("Inside close account ----------------"+acc);
		service.closeAccount(acc);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
