package com.app.daos;

import java.util.List;



import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojo.BankAccount;
import com.app.pojo.Vendor;

@Repository
public class VendorDaoImpl implements VendorDao 
{
	@Autowired
	private SessionFactory sf;

	@Override
	public String registerVendor(Vendor v) 
	{
		return "Vendor registered with ID " +sf.getCurrentSession().save(v);
	}

	@Override
	public Vendor login(String email, String pass) 
	{
		String jpql = "select v from Vendor v where v.email=:em and v.password=:ps";
		return sf.getCurrentSession().createQuery(jpql, Vendor.class).setParameter("em", email).setParameter("ps", pass).getSingleResult();
	}

	@Override
	public List<Vendor> listVendors() 
	{
		
	String jpql = "select v from Vendor v";
	return sf.getCurrentSession().createQuery(jpql, Vendor.class).getResultList();
		
	}

	/*@Override
	public List<BankAccount> listAccounts(Integer vid) {
		String jpql = "select a from BankAccount a where a.vendor.id=:id";
		return sf.getCurrentSession().createQuery(jpql, BankAccount.class).setParameter("id", vid).getResultList();
	}*/

	@Override
	public Vendor getVendorDetails(Integer vid) {
		return sf.getCurrentSession().get(Vendor.class, vid);
	}

	@Override
	public void deleteVendor(Vendor v) {
		sf.getCurrentSession().delete(v);		
	}

	@Override
	public void createAccount(BankAccount acc) {
		sf.getCurrentSession().save(acc);
		
	}

	@Override
	public void closeAccount(BankAccount acc) {
	sf.getCurrentSession().delete(acc);
		
	}

	@Override
	public BankAccount getAccount(Integer aid) 
	{
		return sf.getCurrentSession().get(BankAccount.class, aid);
	}

	@Override
	public List<Long> getAccountNo() {
		String jpql = "select b.accNo from BankAccount b";
		return sf.getCurrentSession().createQuery(jpql,Long.class).getResultList();
		
	}
	@Override
	public BankAccount getAccountDetails(long accNo) {
		String jpql = "select b from BankAccount b where b.accNo=:no";
		return sf.getCurrentSession().createQuery(jpql,BankAccount.class).setParameter("no", accNo).getSingleResult();
	}

	@Override
	public Vendor getBtPhoneNo(String phoneNo) {
		String jpql = "select v from Vendor v where v.phoneNo=:mob";
		return sf.getCurrentSession().createQuery(jpql, Vendor.class).setParameter("mob", phoneNo).getSingleResult();
	}

}
