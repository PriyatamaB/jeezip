package com.app.daos;

import java.util.List;

import com.app.pojo.BankAccount;
import com.app.pojo.Vendor;

public interface VendorDao
{
	public String registerVendor(Vendor v);
	public Vendor login(String email,String pass);
	public List<Vendor> listVendors();
	//public List<BankAccount> listAccounts(Integer vid);
	public Vendor getVendorDetails(Integer vid);
	public void deleteVendor(Vendor v);
	public void createAccount(BankAccount acc);
	public void closeAccount(BankAccount acc);
	public BankAccount getAccount(Integer aid);
	public List<Long> getAccountNo();
	public BankAccount getAccountDetails(long accNo);
	public Vendor getBtPhoneNo(String phoneNo);
	
}
