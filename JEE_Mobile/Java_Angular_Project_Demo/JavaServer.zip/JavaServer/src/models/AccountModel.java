package models;


public class AccountModel 
{
	private Integer aId;
	private String type;
	private double balance;
	private int vId;
	private long accNo;
	
	public AccountModel() {
		// TODO Auto-generated constructor stub
	}

	
	public AccountModel(Integer aId, String type, double balance, int vId, long accNo) {
		super();
		this.aId = aId;
		this.type = type;
		this.balance = balance;
		this.vId = vId;
		this.accNo = accNo;
	}


	public Integer getaId() {
		return aId;
	}

	public void setaId(Integer aId) {
		this.aId = aId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getvId() {
		return vId;
	}

	public void setvId(int vId) {
		this.vId = vId;
	}

	
	public long getAccNo() {
		return accNo;
	}


	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}


	@Override
	public String toString() {
		return "AccountModel [aId=" + aId + ", type=" + type + ", balance=" + balance + ", vId=" + vId + "]";
	}
	
	

}
