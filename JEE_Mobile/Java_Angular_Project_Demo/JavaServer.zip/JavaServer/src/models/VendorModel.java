package models;

import java.util.Date;

public class VendorModel 
{
	private Integer id;
	private String name;
	private String email;
	private String phoneNo;
	private Date bDate;
	private String imgPath;
	private String role;
	
	public VendorModel() {
		// TODO Auto-generated constructor stub
	}

	
	

	public VendorModel(Integer id, String name, String email, String phoneNo, Date bDate, String imgPath) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phoneNo = phoneNo;
		this.bDate = bDate;
		this.imgPath = imgPath;
	}




	public VendorModel(Integer id, String name, String email, String phoneNo, Date bDate, String imgPath,String role) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phoneNo = phoneNo;
		this.bDate = bDate;
		this.imgPath = imgPath;
		this.role =role;
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Date getbDate() {
		return bDate;
	}

	public void setbDate(Date bDate) {
		this.bDate = bDate;
	}
	
	

	public String getImgPath() {
		return imgPath;
	}



	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

	


	public String getRole() {
		return role;
	}



	public void setRole(String role) {
		this.role = role;
	}



	@Override
	public String toString() {
		return "VendorModel [id=" + id + ", name=" + name + ", email=" + email + ", phoneNo=" + phoneNo + ", bDate="
				+ bDate + ", imgPath=" + imgPath + "]";
	}
	
}
