import { Component, OnInit ,Input} from '@angular/core';
import {AccountService} from '../Accounts/account.service'
import {BsModalRef,BsModalService} from 'ngx-bootstrap/modal';
import { Router,ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-accountlist',
  templateUrl: './accountlist.component.html',
  styleUrls: ['./accountlist.component.css']
})
export class AccountlistComponent implements OnInit {

  accounts=[];
 // @Input() userid:number;
 userid:number;
  public modalRef : BsModalRef;
  constructor(private service:AccountService,private modalService:BsModalService,private route: ActivatedRoute) 
  {
    this.userid = Number(this.route.snapshot.paramMap.get('vId'));
  }

  ngOnInit() {
    console.log("VID------------------",this.userid);
    this.getAccounts(this.userid);
  }

  getAccounts(vid:number)
  {
    return this.service.getAccounts(vid).subscribe(result=>{
      this.accounts = result.json();
    });
  }

 
  openCreateAccountPopup(createAccountTemplate)
  {
    this.modalRef = this.modalService.show(createAccountTemplate);
  }

  openCloseAccountPopup(closeAccountTemplate)
  {
    this.modalRef = this.modalService.show(closeAccountTemplate);
  }

  createAccount(userid,form)
  {
    let account = form.value;
      return this.service.createAccount(userid,account).subscribe(result=>{
        this.getAccounts(this.userid);
      });
      
  }

  closeAccount(form)
  {
    let accountNo  = form.value.accNo;
    console.log("ID-----------------------"+accountNo);
    return this.service.closeAccount(accountNo).subscribe(result=>{
      this.getAccounts(this.userid);
    })
  }

  getValidUser():any
  {
  return sessionStorage.getItem("vendor");
  }

}
