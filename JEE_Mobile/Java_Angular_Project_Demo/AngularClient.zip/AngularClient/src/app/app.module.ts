import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import {HttpModule} from '@angular/http';
import {FormsModule} from  '@angular/forms';
import {RouterModule} from '@angular/router';
import {ModalModule} from 'ngx-bootstrap/modal';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations'
import {CarouselModule} from 'ngx-bootstrap/carousel'
import {HttpClientModule} from '@angular/common/http';
import {VendorService} from './vendor/vendor.service'
import {AccountService} from './Accounts/account.service';
import { LoginComponent } from './vendor/login/login/login.component';
import { RegisterComponent } from './vendor/register/register/register.component';
import { AccountlistComponent } from './accountlist/accountlist.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { AdminComponent } from './admin/admin.component';
import { ChangepassComponent } from './changepass/changepass.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    AccountlistComponent,
    CreateaccountComponent,
    AdminComponent,
    ChangepassComponent,
    UpdateprofileComponent
   
  ],
  imports: [
    BrowserModule,HttpModule,FormsModule,
    RouterModule.forRoot([
      {path:"login",component:LoginComponent},
      {path:"register",component:RegisterComponent},
      {path:"admin",component:AdminComponent},
      {path:"accList/:vId",component:AccountlistComponent},
      {path:"changepass",component:ChangepassComponent},
      {path:"update",component:UpdateprofileComponent},
     
    ]),ModalModule.forRoot(),
    HttpClientModule
  ],
  providers: [
    VendorService,AccountService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
