import { Component, OnInit } from '@angular/core';
import {VendorService} from '../vendor/vendor.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})


export class AdminComponent implements OnInit {

  vendors=[];
  constructor(private service:VendorService) {
    this.getVendors();
   }

  getVendors()
  {
    return this.service.getVendors().subscribe(results=>{
      this.vendors = results.json();
    })
  }

  getValidUser():any
  {
  return sessionStorage.getItem("vendor");
  }

  deleteVendor(vid)
  {
    alert("Inside delete......"+vid);
    return this.service.deleteVendor(vid).subscribe(results=>{
      this.getVendors();
    })
  }
  ngOnInit() {
    
  }

}
