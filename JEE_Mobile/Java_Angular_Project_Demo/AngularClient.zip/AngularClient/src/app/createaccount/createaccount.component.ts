import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-createaccount',
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.css']
})
export class CreateaccountComponent implements OnInit {

  @Input() showCreateAccountPopup:boolean;
  constructor() { 
    console.log("create---------------------",this.showCreateAccountPopup)
  }

  ngOnInit() {

    console.log("create---------------------",this.showCreateAccountPopup)
  }

}
