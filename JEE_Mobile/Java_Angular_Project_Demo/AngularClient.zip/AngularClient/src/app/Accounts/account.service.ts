import {Injectable} from '@angular/core'
import {Http,Headers,RequestOptions} from '@angular/http'

@Injectable()
export class AccountService
{
    http:Http;
    baseurl="http://localhost:8080/JavaServer/vendor/";

    constructor(http:Http)
    {
        this.http = http;
    }

   public getAccounts(vid)
    {
        return this.http.get(this.baseurl+"accounts/"+vid);
    }

    public createAccount(vid,account)
    {
        let accountStr = JSON.stringify(account);
        let createAccHeaders = new Headers({ 'Content-type': 'application/json' });
        let createAccOptions = new RequestOptions({headers:createAccHeaders});
        return this.http.post(this.baseurl+"createacc/"+vid,accountStr,createAccOptions);
    }

    public closeAccount(accNo)
    {
        let accountStr = JSON.stringify(accNo);
        let closeAccHeaders = new Headers({ 'Content-type': 'application/json' });
        let closeeAccOptions = new RequestOptions({headers:closeAccHeaders});
        return this.http.delete(this.baseurl+"closeacc/"+accNo);
    }
}